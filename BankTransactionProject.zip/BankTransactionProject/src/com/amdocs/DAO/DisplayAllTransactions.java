package com.amdocs.DAO;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DisplayAllTransactions 
{
	//SQL Query
	private static final String SELECT_ALL_TRANSACTIONS = "SELECT * FROM transactions";
	private static final String SELECT_ALL_INVALID_TRANSACTIONS = "SELECT * FROM InValidTrans";
	private static final String SELECT_ALL_VALID_TRANSACTIONS = "SELECT * FROM ValidTrans";
	
	
	private static Connection con = ConnectionProvider.getConnection();
	public static void displayAllRecords() throws SQLException
	{
		displayTransactionsTable();
		displayValidTransactionTable();
		displayInValidTransactionTable();
	
	}

	private static void displayTransactionsTable() throws SQLException 
	{
		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery(SELECT_ALL_TRANSACTIONS);

		while (rs.next()) 
		{
			int transID = rs.getInt(1);
			int acctNo = rs.getInt(2);
			double oldBal = rs.getDouble(3);
			String transType = rs.getString(4);
			double transAmt = rs.getDouble(5);
			double newBal = rs.getDouble(6);
			String Validity = rs.getString(7);
			
			System.out.println(transID + " | " + acctNo + " | " + oldBal + " | " + transType + " | " + transAmt + " | " + newBal + " | " +  Validity);
			
		}
		
		System.out.println();
		System.out.println();

	}

	private static void displayValidTransactionTable() throws SQLException 
	{
		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery(SELECT_ALL_VALID_TRANSACTIONS);

		while (rs.next()) 
		{
			int transID = rs.getInt(1);
			String transType = rs.getString(2);
			double transAmt = rs.getDouble(3);
			String Validity = rs.getString(4);
			
			System.out.println(transID + " | " +  transType + " | " + transAmt + " | "  +  Validity);
			
		}
		
		System.out.println();
		System.out.println();

	}

	private static void displayInValidTransactionTable() throws SQLException 
	{
		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery(SELECT_ALL_INVALID_TRANSACTIONS);

		while (rs.next()) 
		{
			int transID = rs.getInt(1);
			String transType = rs.getString(2);
			double transAmt = rs.getDouble(3);
			String Validity = rs.getString(4);
			
			System.out.println(transID + " | " +  transType + " | " + transAmt + " | "  +  Validity);
			
		}
		
		System.out.println();
		System.out.println();

		
	}

}
