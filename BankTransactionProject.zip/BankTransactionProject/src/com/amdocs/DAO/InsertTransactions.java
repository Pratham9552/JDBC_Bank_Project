package com.amdocs.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class InsertTransactions 
{
	// SQL queries
		private static final String INSERT_VALID_TRANS = "INSERT INTO ValidTrans VALUES(?, ?, ?, ?)";
		private static final String INSERT_INVALID_TRANS = "INSERT INTO InValidTrans VALUES(?, ?, ?, ?)";

	
	// Insert a transaction into the appropriate table
		public static void insertIntoTransactionTable(Connection con, String tableName, int transID, String transType,
				double transAmt, String validity) throws SQLException 
		{

			// Determine the appropriate SQL query for insertion
			String insertQuery = "";
			if (tableName.equals("ValidTrans")) 
			{
				insertQuery = INSERT_VALID_TRANS;
			} 
			else 
			{
				insertQuery = INSERT_INVALID_TRANS;
			}

			// Prepare and execute the insertion statement
			PreparedStatement ptsmt = con.prepareStatement(insertQuery);

			ptsmt.setInt(1, transID);
			ptsmt.setString(2, transType);
			ptsmt.setDouble(3, transAmt);
			ptsmt.setString(4, validity);
			ptsmt.executeUpdate();

		}


}
